[2022 Mazda 3](https://3dmatsusa.com/products/kagu-floor-liner?variant=42800879698080)

 ![A59366E2-BF46-49B3-97EA-67AB25609190](https://i.imgur.com/iCjlzp6.jpg)