Headphones should be:
* Comfortable (ear cup design).
* Good quality.
* Bluetooth 5 or above.
* Connect to multiple devices simultaneously.
* Wireless.
* Work with Teams.

The [Bose 700 US](https://www.bose.com/en_us/products/headphones/noise_cancelling_headphones/noise-cancelling-headphones-700-conferencing.html) are perfect.