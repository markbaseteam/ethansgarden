

| Plan                    | Image                                                       |
| ----------------------- | ----------------------------------------------------------- |
| Christmas Plan 1 (2014) | ![Christmas Plan 1 (2014)](https://i.imgur.com/8aPPke2.jpg) |
| Christmas Plan 2 (2014) | ![Christmas Plan 2 (2014)](https://i.imgur.com/MJRJhcS.jpg) |
| Christmas Plan 3 (2014) | ![Christmas Plan 3 (2014)](https://i.imgur.com/CoUGWXt.jpg) |
| Christmas Plan 3 (2014) | ![Christmas Plan 3 (2014)](https://i.imgur.com/KmWeNlY.jpg) |
| Christmas Plan 4 (2014) | ![](https://i.imgur.com/9n66wZP.jpg)                        |
| Christmas Plan 5 (2014) | ![](https://i.imgur.com/o4HZ8oL.jpg)                        |
| Christmas Plan 6 (2014) | ![](https://i.imgur.com/TLWHxFn.jpg)                        |
| <mark class="hltr-yellow">Spring Plan 1 (2017)</mark>    | ![](https://i.imgur.com/Fm8QtH6.jpg)                        |
| Spring Plan 2 (2017)    | ![](https://i.imgur.com/Q58hy7X.jpg)                        |
