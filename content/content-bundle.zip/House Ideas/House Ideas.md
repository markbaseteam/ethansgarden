# Reversible Faucets

[Boise International Discount Center - Video Demonstration](https://www.facebook.com/reel/678250943879227?fs=e&s=TIeQ9V&mibextid=0NULKw)

| 1080° Swivel Faucet Aerator Extension                                                                            | Price |
| ---------------------------------------------------------------------------------------------------------------- | ----- |
| [LEWEDO](https://www.amazon.com/LEWEDO-Extender-Universal-Portable-different/dp/B0BD4KY6Y8/ref=sr_1_3_sspa)      | $17   |
| [Spurtar](https://www.amazon.com/Spurtar-Rotatable-Multifunctional-Extension-Universal/dp/B0B6ZFC1W1/ref=sr_1_6) | $19   |

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/61ec4xkE0cL._AC_SL1500_.jpg)

# Corner Drawers

[Austin Jenkins - Video Demonstration](https://www.facebook.com/inspector.aj/videos/773173867075785/)

# Heated Floors

[Chris Lacharity - Video Demonstration](https://www.facebook.com/reel/669813454724497?fs=e&s=TIeQ9V&mibextid=0NULKw)

[Install Radiant Heat Under Wood Floor 24 Inches OC](https://www.youtube.com/watch?v=tlz_ukxS_TQ)

# Machine Bathtub Scrubber

[Caroline McCauley - Video Demonstration](https://www.facebook.com/reel/3049793918568337?fs=e&s=TIeQ9V&mibextid=0NULKw)

[Electric Spin Scrubber](https://www.amazon.com/dp/B098355866/ref=cm_sw_r_as_gl_api_gl_i_FN50B26HKVAQMY7WZRFA?linkCode=ml1&tag=carolinamcc0e-20)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/715gv+b8TAL._AC_SL1500_.jpg)
# Steam Cleaner

[Steam Cleaner](https://www.amazon.com/dp/B09Y3CWMT1/ref=cm_sw_r_as_gl_undefined?linkCode=ml2&tag=carolinamcc0e-20)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/61RwQI5pcDL._AC_SL1500_.jpg)

# Foldable Bed into Dresser

[MattressLand & Furniture - Video Demonstration](https://www.facebook.com/reel/803041237431592?fs=e&s=TIeQ9V&mibextid=0NULKw)

# Airtight Containers for Top Shelf

Home Design Gadgets

* [Small Airtight Easy Pour Food Container](https://www.amazon.com/Joseph-81111-CupboardStore-Container-Undershelf/dp/B07YLF9ZJ9/ref=sr_1_2)
* [Large Airtight Easy Pour Food Container](https://www.amazon.com/Joseph-81112-CupboardStore-Container-Undershelf/dp/B07YLFMF9G/ref=sr_1_3)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/518JG-ggADL._AC_SL1000_.jpg)

# Floss Dispenser

# Deep Cleaner

[BISSELL SpotClean Pro](https://www.bissell.com/bissell-spotclean-pro-portable-carpet-cleaner-3194.html) - [$165](https://a.co/d/dUTV1ak)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/51vXTyKr+BL._AC_SL1001_.jpg)

[Instructions](https://media.flixcar.com/f360cdn/Bissell-2126712403-user-guide_1558.pdf#page=5)

# Mattress

![](https://casper.com/dw/image/v2/BFHV_PRD/on/demandware.static/-/Library-Sites-casper-shared/default/dw3ac54510/Content%20Pages/mattress-size-guide-size-chart.png)

## Queen Golden Mattress

```
The Premiere 
A perfect blend of comfort and support
The Heirloom Collection by Golden Mattress
WT69269
```

* [$500 - $670](https://www.mattresscentraltexas.com/_CGI/SEARCH3.HTML?MAN_SORT=GLDN&MAJOR=MATR&MATTRESS_SIZE_SORT=QUEEN)
* [$255](https://dallasfurnitureonline.com/full1.html)

### Premier Pillowtop
  
Giving the Eurotop a run for first place in this collection, the Pillowtop has a medium-soft feel to it. Pillowtops in general run softer than Eurotops so that makes this mattress a much needed addition to the Premier collection. ([Golden Mattress](https://www.goldenmattressdallas.com/premier.html))

## Twin XL Biopedic

Luxurious Comfort
Company name: Golden Pedic INC
Street: 1240 Titan Dr.
City, State: Dallas, TX 75247
Date of Manufacture: Jun 2 3 2009
Model: GM3NT

```
Mattress:
Polyurethane Foam ... 70%
Fiber Pad ........... 30%
Spring
```


# Smart Plug

‎TP-Link Kasa Smart Wi-Fi Plug Slip - [$30 (4-Pack)](https://www.amazon.com/TP-Link-Kasa-Smart-Wifi-Plug/dp/B07RCNB2L3/ref=sr_1_6)

![](https://static.tp-link.com/upload/image-line/22_EP25P4_01_1000x1000_normal_20220616184625u.png)

* [How to set up my TP-Link Smart Plug Switch via Kasa](https://www.tp-link.com/us/support/faq/946/)
* [Use Siri to Control Smart Devices](https://www.tp-link.com/us/support/faq/2528/) (IFTTT only allows 2 free applets)

The best say to control Kasa devices with Siri is by creating Shortcuts.

# Smart Switch

[Smart Wi-Fi Light Switch](https://www.kasasmart.com/us/products/smart-switches/kasa-smart-wifi-light-switch-motion-activated-ks200m)

# Smart Light

# Smart Remote Switch

[Pico Smart Remotes by Lutron](https://www.casetawireless.com/us/en/products/pico-remotes)

Community:
* [Need a Kasa remote control switch!](https://community.tp-link.com/en/home/forum/topic/209538)

> I have a wall switch configured to remotely control a table lamp that is plugged into a Kasa smart plug.

# Door Shoe Hanger

* MISSLO Over The Door Organizer - [$13](https://www.amazon.com/MISSLO-Organizer-Large-Storage-Pockets/dp/B01D9VYQTC/ref=asc_df_B01D9VYQTC/)
* Mainstays 12-Tier Over The Door Shoe Rack - [$25](https://www.walmart.com/ip/Mainstays-12-Tier-Over-The-Door-Shoe-Rack-Metal-Gray/850099411)
* SimpleHouseware Crystal Clear Over The Door Hanging Shoe Organizer - [$9](https://www.amazon.com/24-Pockets-SimpleHouseware-Crystal-Organizer/dp/B01D58DRVC/ref=sr_1_1_sspa)

## Mesh Racks

* <mark class="hltr-yellow">Gorilla Grip Shoe Holder Rack</mark> - [$13](https://www.amazon.com/Gorilla-Grip-Organizer-Breathable-Accessories/dp/B088KV58F5/ref=sr_1_2_sspa)
* AOODA 28 Large Mesh Pockets Over The Door Shoe Rack - [$16](https://www.amazon.com/AOODA-Pockets-Hanging-Organizer-Closet/dp/B08T67MSBJ/ref=sr_1_3_sspa)
* Lifewit Over The Door Hanging Shoe Organizer - [$15](https://www.amazon.com/dp/B09GLLK579)

![](https://m.media-amazon.com/images/I/41x8kyoWwqL._AC_SL1000_.jpg)

## Will the weight damage my door?

Filled with 12 pairs of shoes, the Shoe Rack is 18 pounds. A 24x80 Hollow core door weighs about [14 pounds](https://absupply.net/pdf/KV_Door-Weight-Table.pdf). 

![](https://i.imgur.com/sbTmi4V.png)

According to *The DIY Plan*, a set of 3 standard residential duty door hinges with steel pins can support 70 pounds with high frequency.

| Door Hinge Type                         | Medium Frequency | High Frequency    |
|-----------------------------------------|------------------|-------------------|
| Residential duty interior hinge (2 set) | 90 pounds        | 45 pounds         |
| Residential duty interior hinge (3 set) | 120 pounds       | <mark class="hltr-yellow">70</mark> pounds        |
| Residential duty hinge                  | 400 pounds       | 200 pounds        |
| Commercial Duty Hinge                   | 600 pounds       | 400 pounds        |
| Heavy duty hinge                        | 1000 pounds      | 600 pounds        |
| Cabinet Doors                           |  ~ 80 pounds     | ~ 80 pounds total |


Thus even with 12 pounds of shoes added, standard hinges have a 174 pound clearance.

$$70lb - 12lb - 14lb = 44lb$$


According to *The Hinge Guys* there are [3 types of door hinges](https://www.select-hinges.com/blog/27-standard-or-heavy-duty-hinges) for exterior doors:

1. **Standard Duty** - For low- or medium-frequency doors <mark class="hltr-yellow">up to 200 lb</mark>. without frame or door reinforcement.
2. **Heavy Duty** - For high-frequency doors up to 200 lb. or medium-frequency doors up to 400 lb., both without frame or door reinforcement; or low-frequency doors up to 600 lb. with the use of Rivnuts in the frame and door.
3. **Heavy Duty (LL)** - For low-frequency doors up to 1,000 lb., including most lead-lined doors. (SELECT uses HD hinges with additional fastener holes.) Rivnuts are recommended in the frame and door on extremely tall, extremely heavy or wide doors. (Pyatte)

Thus even with 12 pounds of shoes added, standard hinges have a 174 pound clearance.

$$200lb - 12lb - 14lb = 174lb$$

---

Pyatte, Stephen. “[Standard or Heavy Duty Hinges?](https://www.select-hinges.com/blog/27-standard-or-heavy-duty-hinges)” _Select Hinges_, The Hinge Guys.

Viktor. “[How Much Weight Can I Hang on a Door?](https://thediyplan.com/how-much-weight-can-i-hang-on-a-door)” _TheDIYPlan_, 28 May 2021.

Admin. "[Do Doors Need 2 Hinges or 3 Hinges?](https://monroeengineering.com/blog/do-doors-need-2-hinges-or-3-hinges)" *Monroe Engineering*, One Monroe, 15 Mar. 2022.

# Foldimate

[FOLDIMATE](https://www.youtube.com/watch?v=2kv9eeKqmNk)
[Foldimate’s laundry-folding machine actually works now](https://www.theverge.com/2019/1/7/18171441/foldimate-laundry-folding-robot-ces-2019)

# Life Hacks

[Life hacks and tips](https://fb.watch/jtyPg8VL0i/?mibextid=YCRy0i).