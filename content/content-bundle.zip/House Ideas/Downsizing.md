# Video Capture Card | Dazzle by Pinnacle

[Pinnacle Dazzle DVD Recorder HD](https://www.amazon.com/Dazzle-DVD-Recorder-VHS-Converter/dp/B00EAS14KI)

![](https://www.pinnaclesys.com/static/pin/images/products/dazzle/video-capture-device.jpg)

# DVD Cover Protective Sleeves

[Tarifold DVD Protective Sleeve for DVD Storage with Binder Holes](https://www.amazon.com/dp/B07SFYCD3Q)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/71H9Eh2ZnSL._AC_SL1200_.jpg)

[BEST DVD STORAGE ORGANIZER!!](https://www.youtube.com/watch?v=6RXp4U4KFqA)

[What Should We Do with Old DVDs and CDs?](https://www.youtube.com/watch?v=ys3QPy0GSeM)

-------------------------

[mediaxpo 500 CPP Clear Plastic Sleeve with Flap](https://www.amazon.com/gp/product/B00OAYKBQ0)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/91kNvMRuTfL._AC_SL1500_.jpg)

[Mxfans 500pcs White OPP Plastic Double-Sided CD DVD Sleeves with Window & Flap](https://www.amazon.com/gp/product/B07DS8Y2RY)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/71HWR1q2LGL._AC_SL1500_.jpg)

[Efficient way to store an ever expanding DVD/Blu-ray collection in a small space](https://www.youtube.com/watch?v=FsV-jfoEGMg)

# Blu-ray burner

[External Blu ray Drive DVD/BD Player](https://www.amazon.com/External-Portable-Blu-ray-DriveCompatible-SpeedSilent/dp/B07DL5WQPN/ref=sr_1_1_sspa)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/713POkG846L._AC_SL1500_.jpg)