# Dad

[Flat plug extension cord](https://www.amazon.com/gp/product/B077NQB72S/ref=ppx_yo_dt_b_asin_title_o02_s01?ie=UTF8&th=1)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/41-oa+2KbBL._AC_.jpg)

[Ooma Water Sensor](https://www.amazon.com/Ooma-Water-Sensor-works-Telo/dp/B071WMHWTH/ref=sr_1_1)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/71RiRTBJwwL._AC_SL1500_.jpg)

[SaladMaster knife](https://saladmaster.com/en-us/our-products/product-details/cutlery-set)

![](https://saladmaster.com/DesktopModules/Revindex.Dnn.RevindexStorefront/Portals/1/Gallery/ea398239-2ecf-470d-87b8-acdae32ae4f8.jpg)

[Digital Clock](https://www.amazon.com/dp/B07L4B6LYB/?coliid=I2A61VP0JI4OAE&colid=2JZKFTGNBQ2GJ&psc=1&ref_=lv_ov_lig_dp_it)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/61aHpABj+BL._AC_SL1500_.jpg)

[Chair Pads](https://www.amazon.com/dp/B086STL296/)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/61bvH3PNA6L._AC_SL1200_.jpg)

[Glue lamenate](https://www.amazon.com/Cal-Flor-GL82114CF-Eurobond-Floating-Floor/dp/B003DKSWK4/ref=sr_1_3)

![](https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/81mE0p+GWUL._AC_SL1500_.jpg)