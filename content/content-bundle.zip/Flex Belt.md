Manuals
The Flex Arms
[The Flex Belt](https://www.qvc.com/footers/ws/pdf/F12189_Manual.pdf)
The Flex Mini