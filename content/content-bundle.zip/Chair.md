# HOMCOM Massage Chair

[HOMCOM Red Faux Leather Massage Computer Gaming Chair Racing Style Ergonomic Heated - $271.39](https://images.thdstatic.com/productImages/f70bd547-ff89-4195-8476-d2d47c0d1232/svn/red-homcom-gaming-chairs-921-057rd-64_600.jpg)

![](https://images.thdstatic.com/productImages/f70bd547-ff89-4195-8476-d2d47c0d1232/svn/red-homcom-gaming-chairs-921-057rd-64_600.jpg)

# Sadie High-Back Task Chair

[Sadie High-Back Task Chair | Height Adjustable Arms | Height Adjustable Back - $545](https://www.hon.com/chairs/sadie-chairs/hvst121)

![](https://res.cloudinary.com/hni-corporation/image/upload/b_white,c_pad,dpr_1.0,f_auto,h_675,q_auto,w_1200/c_pad,h_675,w_1200/v1/HON/Chairs/Sadie%20Chairs/basyx-HighBackTask-HVST121-045-001?pgw=1)