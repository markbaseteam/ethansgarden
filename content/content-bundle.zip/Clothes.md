# Tommy Hilfiger Men's Arctic Cloth Hooded Utility Bomber
* [$225 - Dick’s](https://www.dickssportinggoods.com/p/tommy-hilfiger-performance-artic-cloth-hooded-utility-jacket-21thimrctcclthhddapo/21thimrctcclthhddapo)
* [$82 - Amazon](https://a.co/d/dhNyE)

![](https://dks.scene7.com/is/image/GolfGalaxy/151AP577_WHT-White_MODSTL?qlt=70&wid=250&fmt=webp&op_sharpen=1)

