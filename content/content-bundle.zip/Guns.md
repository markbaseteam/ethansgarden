# Ruger LCP II

| Model:         | [13705](https://ruger.com/products/lcpII/specSheets/13705.html)    |
|----------------|----------|
| Caliber:       | 22 LR    |
| Capacity:      | 10+1     |
| Barrel Length: | 2.75"    |
| Sights:        | Integral |
| MSRP:          | $439.00  |

![](https://ruger.com/productImages/13705/detail/1.jpg)

## Ammo

### .380 ACP

[Federal American Eagle](https://www.cheaperthandirt.com/federal-american-eagle-.380-acp-ammunition-95-grain-fmj-980-fps/FC-AMM-3173.html)

Tip: Get Jacketed Hollow Point Ammo (JHP) to prevent bullet from going through walls.